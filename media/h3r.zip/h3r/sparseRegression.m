function [e, res] = sparseRegression( B, noisyLabel, params )
% B ----------------------------------- Hessian matrix that encodes manifold topology
% noisyLabel -------------------------- N * 1 noisy manifold label
% params.lambda ----------------------- weight term on L1 
% params.gnd (optional)---------------- groundtruth manifold label, used to compute RMSE

% res.f ------------------------------- denoised labels 
% res.E ------------------------------- value of the objective function after optimization
% res.frmse --------------------------- RMSE between ground truth and denoised label 

% AUTHOR    Hui Wu <wuhu@us.ibm.com>
% UPDATE    12/17/2015

N = size(B,1);

[A, isSim] = chol(B); 
if(isSim > 0)
    %fprintf('size of A is (%d, %d)\n', size(A,1), size(A,2));
    A = cat(1,A, zeros(N - size(A,1),N));
end

y = - A * noisyLabel;
e = zeros(size(y)); 
[e,~]=l1_ls(A, y, params.lambda, 0.01); % tolerance = 0.01, may be changed to other values

res.f = noisyLabel + e; 

if(isfield(params, 'gnd'))
    res.frmse = myrmse(res.f, params.gnd);
end

% the value of the final objective function
res.E = [res.f' * B * res.f , params.lambda * sum(abs(e))]; 
   
end

function diff = myrmse(x1, x2)
	diff = sqrt(mean((x1-x2).^2,1)); 
end
