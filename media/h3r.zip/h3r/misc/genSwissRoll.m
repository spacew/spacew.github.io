function [X, coords, gndLabel, noisyLabel] = genSwissRoll(N, noiseRatio)
% INPUT: 
% N ------------------- number of data points
% noiseRatio ---------- percentage of points that will be corrupted
% OUTPUT:
% X ------------------- N*3 matrix, the 'image manifold' 
% coords -------------- N*2 matrix, the intrinsic coordinates on the manifold, used for visualization purpose
% gndLabel ------------ noise free labels
% noisyLabel ---------- noisy labels

% AUTHOR    Hui Wu <wuhu@us.ibm.com>
% UPDATE    12/17/2015

tRoll = (3 * pi / 2) * (1 + 2 * rand(N, 1));  
tHeight = 30 * rand(N, 1);
X = [tRoll .* cos(tRoll) tHeight tRoll .* sin(tRoll)] + 0.05 * randn(N, 3);
rng('default')
coords = [tRoll tHeight];
coords = bsxfun(@minus, coords, min(coords,[],1)); 
coords = bsxfun(@times, coords, 1./max(coords,[],1));

% generate a function on the manifold
gndLabel = sin(sqrt(sum((bsxfun(@minus,coords,[0.5 0.5])).^2,2))*2*pi);
gndLabel = gndLabel/2 +0.5; 

% add noise to the ground truth function labels
range = max(gndLabel(:) - min(gndLabel(:))); 
noisyIndex = sort(randperm(length(gndLabel), floor(length(gndLabel)*noiseRatio)));
noisyLabel = gndLabel; 
noisyLabel(noisyIndex) = (rand(length(noisyIndex),1)-1/2) * range + noisyLabel(noisyIndex);

end