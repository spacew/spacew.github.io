% this script takes about 1 min to run on a standard PC
addpath(genpath('.')); 

% ----------- generate swiss roll data set ---------
noiseRatio = .5; 
N = 3000; % number of data points (images) 
[X, coords, gndLabel, noisyLabel] = genSwissRoll(N, noiseRatio);    

% ------------ robust manifold regression -------------------
k = 10;           % number of nearest neighbors on the manifold
dim = 2;          % intrinsic dimension of the manifold 
params.lambda = 100/N; % this trade-off parameter can be tuned 

D = L2_distance(X',X',0); 
[~,NNindOri] = sort(D,2,'ascend');
NNind = NNindOri(:,1:k); 
B = ConstructHessian(X, NNind, struct('DimGiven',1, 'NCoordDim', dim) ); 

fprintf('computing denoised labels ... \n'); 
[~, output] = sparseRegression( B, noisyLabel, params );
denoisedLabel = output.f; 
fprintf('Done. \n'); 
% ------------ Visualize results -------------------

% get a nice looking colormap
mymap01 = fire(300);
mymap02 = fire(100); 
mymap = [mymap01(1:end/2,:); mymap02(end/2:end,:)];
mymap = mymap(1:round(0.95*size(mymap,1)),:); 

figure; 
set(gcf,'Position', [853   232   771   629]); 

subplot(231); 
scatter3(X(:,1), X(:,2), X(:,3), 20, gndLabel, 'filled')
axis tight; axis equal; set(gca, 'FontSize',10); 
caxis([0 1]); colormap(mymap)
title('Manifold with ground truth labels', 'FontSize', 10)
campos([27.0006 -208.2462   25.1424])

subplot(232); 
scatter3(X(:,1), X(:,2), X(:,3), 20, noisyLabel, 'filled')
axis tight; axis equal; set(gca, 'FontSize',10); 
caxis([0 1]);colormap(mymap)
title('Manifold with noisy labels', 'FontSize', 10)
campos([27.0006 -208.2462   25.1424])

subplot(233); 
scatter3(X(:,1), X(:,2), X(:,3), 20, denoisedLabel, 'filled')
axis tight; axis equal; set(gca, 'FontSize',10); 
caxis([0 1]);colormap(mymap)
title('Denoised result', 'FontSize', 10)
campos([27.0006 -208.2462   25.1424])

subplot(234); 
scatter(coords(:,1), coords(:,2), 25, gndLabel, 'filled'); 
axis equal; axis tight; axis([0 1 0 1]); axis([0 1 0 1])
caxis([0 1]); colormap(mymap)
title('Ground truth visualized in 2D', 'FontSize', 10)

subplot(235); 
scatter(coords(:,1), coords(:,2), 25, noisyLabel, 'filled'); 
axis equal; axis tight; axis([0 1 0 1]); axis([0 1 0 1])
caxis([0 1]); colormap(mymap)
title('Noisy labels visualized in 2D', 'FontSize', 10)

subplot(236); 
scatter(coords(:,1), coords(:,2), 25, denoisedLabel, 'filled'); 
axis equal; axis tight; axis([0 1 0 1]); axis([0 1 0 1])
caxis([0 1]); colormap(mymap)
title('Denoised labels visualized in 2D', 'FontSize', 10)


